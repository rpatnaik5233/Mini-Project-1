CREATE TABLE EmployeeMaster
(
EmployeeId VARCHAR(10) NOT NULL PRIMARY KEY,
EmployeeName VARCHAR(30),
Password VARCHAR(20),
Role VARCHAR(20)
);

CREATE TABLE FacultySkill
(
EmployeeId VARCHAR(10) FOREIGN KEY REFERENCES EmployeeMaster(EmployeeId),
SkillSet VARCHAR(100)
);

CREATE TABLE CourseMaster
(
CourseCode VARCHAR(10) NOT NULL PRIMARY KEY,
CourseName VARCHAR(100),
NoOfDays int
);


CREATE TABLE TrainingProgram
(
TrainingCode VARCHAR(10),
CourseCode VARCHAR(10),
facultyCode VARCHAR(10),
StartDate DATE,
EndDate DATE,
PRIMARY KEY(TrainingCode),
FOREIGN KEY(CourseCode) REFERENCES CourseMaster(CourseCode),
FOREIGN KEY(facultyCode) REFERENCES EmployeeMaster(EmployeeId)
);

CREATE TABLE FeedbackMaster
(
TrainingCode VARCHAR(10) FOREIGN KEY REFERENCES TrainingProgram(TrainingCode),
participantCode VARCHAR(10) FOREIGN KEY REFERENCES EmployeeMaster(EmployeeId),
PresentationCommunication int,
ClarifyDoubts int,
TimeManagaement int,
HandOuts int,
HwSwNw int,
Comments VARCHAR(100),
Suggestions VARCHAR(100)
);

CREATE TABLE TrainingParticipantEnrollment
(
TrainingCode VARCHAR(10) FOREIGN KEY REFERENCES TrainingProgram(TrainingCode),
participantCode VARCHAR(10) FOREIGN KEY REFERENCES EmployeeMaster(EmployeeId)
);

CREATE SEQUENCE courseId_sequence
START WITH 100
INCREMENT BY 1;

CREATE SEQUENCE trainingId_sequence
START WITH 1000
INCREMENT BY 1;

