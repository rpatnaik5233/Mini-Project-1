package com.cg.dao;

import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;

public interface ITrainingAdminDAO 
{
	
	public boolean facultyMaintenance(FacultySkillBean faculty) throws FeedBackException;
	public boolean courseMaintenance(CourseMasterBean course) throws FeedBackException;
	public List<FacultySkillBean> viewFaculty() throws  FeedBackException;
	public boolean updateFaculty(FacultySkillBean faculty) throws  FeedBackException;
	public boolean deleteFaculty(String facultyCode) throws  FeedBackException;
	public List<FeedbackMasterBean> viewFacultyWiseReport(int month) throws  FeedBackException;
	public FacultySkillBean retrieveFaculty(String facultyCode);
	public String retrieveFacultyCode(String trainingCode);


}
