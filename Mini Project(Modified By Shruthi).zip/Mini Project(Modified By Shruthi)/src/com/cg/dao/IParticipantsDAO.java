package com.cg.dao;

import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;

public interface IParticipantsDAO {
	
	public boolean participantFeedback(FeedbackMasterBean feedBack) throws  FeedBackException;
	public String retrieveTrCode(String employeeId) throws FeedBackException;

}
