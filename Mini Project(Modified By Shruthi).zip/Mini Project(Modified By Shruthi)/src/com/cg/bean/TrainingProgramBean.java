package com.cg.bean;

import java.util.Date;

public class TrainingProgramBean {
	
	private String trainingCode;
	private String courseCode;
	private String facultyCode;
	private Date startDate;
	private Date endtDate;
	
	public TrainingProgramBean() {
		super();
	}

	public TrainingProgramBean(String trainingCode, String courseCode, String facultyCode, Date startDate,
			Date endtDate) {
		super();
		this.trainingCode = trainingCode;
		this.courseCode = courseCode;
		this.facultyCode = facultyCode;
		this.startDate = startDate;
		this.endtDate = endtDate;
	}

	public String getTrainingCode() {
		return trainingCode;
	}

	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}

	public String getCourseCode() {
		return courseCode;
	}

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	public String getFacultyCode() {
		return facultyCode;
	}

	public void setFacultyCode(String facultyCode) {
		this.facultyCode = facultyCode;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndtDate() {
		return endtDate;
	}

	public void setEndtDate(Date endtDate) {
		this.endtDate = endtDate;
	}

	@Override
	public String toString() {
		return "TrainingProgramBean [trainingCode=" + trainingCode + ", courseCode=" + courseCode + ", facultyCode="
				+ facultyCode + ", startDate=" + startDate + ", endtDate=" + endtDate + "]";
	}
	
}
