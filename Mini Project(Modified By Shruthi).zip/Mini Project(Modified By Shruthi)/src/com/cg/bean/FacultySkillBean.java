package com.cg.bean;

public class FacultySkillBean {
	
	private String facultyCode;
	private String skillSet;
	private String facultyName;
	public FacultySkillBean() {
		super();
	}
	public FacultySkillBean(String facultyCode, String skillSet,
			String facultyName) {
		super();
		this.facultyCode = facultyCode;
		this.skillSet = skillSet;
		this.facultyName = facultyName;
	}
	public String getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(String facultyCode) {
		this.facultyCode = facultyCode;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	@Override
	public String toString() {
		return "FacultySkillBean [facultyCode=" + facultyCode + ", skillSet="
				+ skillSet + ", facultyName=" + facultyName + "]";
	}
	
	
	
}

