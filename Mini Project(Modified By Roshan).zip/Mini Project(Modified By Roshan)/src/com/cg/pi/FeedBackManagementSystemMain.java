package com.cg.pi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.TrainingProgramBean;
import com.cg.exception.FeedBackException;
import com.cg.service.IServiceTrainingCoordinators;
import com.cg.service.ServiceTrainingCoordinatorsImpl;



public class FeedBackManagementSystemMain {
	
	public static void main(String[] args) throws FeedBackException {
		boolean isInserted = false;
	IServiceTrainingCoordinators coordinatorService = new ServiceTrainingCoordinatorsImpl();
	CourseMasterBean bean = new CourseMasterBean();
	
	List<TrainingProgramBean> trainingProgramList=null;
	/*DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	String sDate = "10/11/2017";
	TemporalAccessor taS = dtf.parse(sDate);
	LocalDate localSDate = LocalDate.from(taS);
	java.sql.Date startDate = java.sql.Date.valueOf(localSDate);
	
	String eDate = "10/11/2017";
	TemporalAccessor taE = dtf.parse(eDate);
	LocalDate localEDate = LocalDate.from(taE);
	java.sql.Date endDate = java.sql.Date.valueOf(localEDate);
	
	 TrainingProgramBean trainingProgram=new TrainingProgramBean();
		bean.setCourseCode("101");
	 trainingProgram.setFacultyCode("1001");
	 trainingProgram.setStartDate(startDate);
	 trainingProgram.setEndtDate(endDate);
	
	isInserted = coordinatorService.trainingProgramMaintenance(trainingProgram);
*/


	/*EmployeeMasterBean employee = new EmployeeMasterBean();
	employee.setEmployeeId("1001");
	employee.setEmployeeName("Krishna");
	employee.setPassword("rama");
	employee.setRole("Training Coordinator");
	
	isInserted = coordinatorService.employeeParticipant(employee);
	if(isInserted)
	{
		System.out.println("Inserted");
	}
	else
	{
		System.out.println("Not inserted");
	}*/

	
	/*trainingProgramList=coordinatorService.viewTrainingProgram();
	
	for(TrainingProgramBean trainingProgramBean: trainingProgramList)
		System.out.println(trainingProgramBean);
	System.out.println("=================================");*/
	
/*	System.out.println("Enter Trainee Code: ");
	String trainingCode="1001";
	boolean isUpdated=coordinatorService.updateTraining(trainingCode);
	
	if(isUpdated)
		System.out.println("Trainee Details Updated!");
	else
		System.out.println("Invalid Trainee Code");*/
	
	/*System.out.println("Enter Trainee Code: ");
	String trainingCode="1001";
	boolean isDeleted = coordinatorService.deleteTraining(trainingCode);
	
	if(isDeleted)
		System.out.println("Trainee Deleted!");
	else
		System.out.println("Invalid Trainee Code");*/
	
	
	
	}
}

	
	