package com.cg.service;

import java.sql.Date;
import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.dao.ITrainingAdminDAO;
import com.cg.exception.FeedBackException;

public class ServiceTrainingAdminImpl implements IServiceTrainingAdmin {

	ITrainingAdminDAO trainingAdminDAO;
	@Override
	public boolean facultyMaintenance(FacultySkillBean faculty)
			throws FeedBackException {
		boolean isInserted=false;
		isInserted=trainingAdminDAO.facultyMaintenance(faculty);
		return isInserted;
	}

	@Override
	public boolean courseMaintenance(CourseMasterBean course)
			throws FeedBackException {
		
		boolean isInserted=false;
		isInserted=trainingAdminDAO.courseMaintenance(course);
		return isInserted;
	}

	@Override
	public List<FacultySkillBean> viewFaculty() throws FeedBackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateFaculty(FacultySkillBean faculty)
			throws FeedBackException {
		boolean isUpdated=false;
		isUpdated=trainingAdminDAO.updateFaculty(faculty);
		return isUpdated;
	}

	@Override
	public boolean deleteFaculty(String facultyCode) throws FeedBackException {
		boolean isDeleted=false;
		isDeleted=trainingAdminDAO.deleteFaculty(facultyCode);
		return isDeleted;
	}

	@Override
	public List<FeedbackMasterBean> viewFacultyWiseReport(Date startDate,Date endDate)
			throws FeedBackException {
		
		return trainingAdminDAO.viewFacultyWiseReport(startDate,endDate);
	}

	@Override
	public FacultySkillBean retrieveFaculty(String facultyCode) throws FeedBackException {
		
		return trainingAdminDAO.retrieveFaculty(facultyCode);
	}

	@Override
	public String retrieveFacultyCode(String trainingCode) throws FeedBackException {
		
		return trainingAdminDAO.retrieveFacultyCode(trainingCode);
	}
	
	

}
