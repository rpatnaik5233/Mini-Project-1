package com.cg.service;

import com.cg.bean.FeedbackMasterBean;
import com.cg.dao.IParticipantsDAO;
import com.cg.exception.FeedBackException;

public class ServiceParticipantsImpl implements IServiceParticipants {
IParticipantsDAO participantDAO;
	@Override
	public boolean participantFeedback(FeedbackMasterBean feedBack)
			throws FeedBackException {
		boolean isInserted=participantDAO.participantFeedback(feedBack);
		return isInserted;
	}

	@Override
	public String retrieveTrCode(String employeeCode) {
		return participantDAO.retrieveTrCode(employeeCode);
	}

}
