package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;
import com.cg.util.DBConnection;

public class TrainingAdminDAOImpl implements ITrainingAdminDAO {

	@Override
	public boolean facultyMaintenance(FacultySkillBean faculty)
			throws FeedBackException {

		Connection connection = DBConnection.getInstance().getConnection();

		PreparedStatement preparedStatement = null;

		boolean isInserted = false;
		int queryResult = 0;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.FACULTY_MAINTENANCE);

			preparedStatement.setString(1, faculty.getFacultyCode());
			preparedStatement.setString(2, faculty.getSkillSet());
			preparedStatement.setString(3, faculty.getFacultyName());
			queryResult = preparedStatement.executeUpdate();
			if (queryResult > 0) {
				isInserted = true;
			} else {
				isInserted = false;
			}

		} catch (SQLException sqlException) {

			throw new FeedBackException("Tehnical problem occured refer log");
		}

		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {

				throw new FeedBackException("Error in closing db connection");

			}
		}

		return isInserted;
	}

	@Override
	public boolean courseMaintenance(CourseMasterBean course)
			throws FeedBackException {

		Connection connection = DBConnection.getInstance().getConnection();

		PreparedStatement preparedStatement = null;

		boolean isInserted = false;
		int queryResult = 0;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.COURSE_MAINTENANCE);

			preparedStatement.setString(1, course.getCourseName());
			preparedStatement.setInt(2, course.getNoOfDays());
			queryResult = preparedStatement.executeUpdate();
			if (queryResult > 0) {
				isInserted = true;
			} else {
				isInserted = false;
			}

		} catch (SQLException sqlException) {

			throw new FeedBackException("Tehnical problem occured refer log");
		}

		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {

				throw new FeedBackException("Error in closing db connection");

			}
		}

		return isInserted;

	}

	@Override
	public List<FacultySkillBean> viewFaculty() throws FeedBackException {

		Connection con = DBConnection.getInstance().getConnection();
		int facultyCount = 0;

		PreparedStatement ps = null;
		ResultSet resultset = null;

		List<FacultySkillBean> facultyList = new ArrayList<FacultySkillBean>();
		try {
			ps = con.prepareStatement(QueryMapper.VIEW_FACULTY_MAINTENANCE);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				FacultySkillBean facultySkillbean = new FacultySkillBean();
				facultySkillbean.setFacultyName(resultset.getString(1));
				facultySkillbean.setSkillSet(resultset.getString(2));

				facultyList.add(facultySkillbean);

				facultyCount++;
			}

		} catch (SQLException sqlException) {
			/* logger.error(sqlException.getMessage()); */
			throw new FeedBackException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultset.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				/* logger.error(e.getMessage()); */
				throw new FeedBackException("Error in closing db connection");

			}
		}

		if (facultyCount == 0)
			return null;
		else
			return facultyList;
	}

	@Override
	public boolean updateFaculty(FacultySkillBean faculty)
			throws FeedBackException {
		int records = 0;
		boolean isUpdated = false;

		try (Connection conn = DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement = conn
						.prepareStatement(QueryMapper.UPDATE_FACULTY_MAINTENANCE);) {

			preparedStatement.setString(1, faculty.getFacultyName());
			preparedStatement.setString(2, faculty.getSkillSet());
			preparedStatement.setString(3, faculty.getFacultyCode());

			records = preparedStatement.executeUpdate();

			if (records > 0)
				isUpdated = true;

		} catch (SQLException sqlEx) {
			throw new FeedBackException(sqlEx.getMessage());
		}

		return isUpdated;

	}

	@Override
	public boolean deleteFaculty(String facultyCode) throws FeedBackException {
		int records = 0;
		boolean isDeleted = false;
		try (Connection connEmployee = DBConnection.getInstance()
				.getConnection();
				PreparedStatement preparedStatement = connEmployee
						.prepareStatement(QueryMapper.DELETE_FACULTY_MAINTENANCE);) {
			preparedStatement.setString(1, facultyCode);

			records = preparedStatement.executeUpdate();
			if (records > 0) {
				isDeleted = true;
			}
		} catch (SQLException sqlEx) {
			throw new FeedBackException(sqlEx.getMessage());
		}

		return isDeleted;
	}

	@Override
	public List<FeedbackMasterBean> viewFacultyWiseReport(Date startDate,Date endDate)
			throws FeedBackException {
		List<FeedbackMasterBean> feedbackList=new ArrayList<FeedbackMasterBean>();
		
		FeedbackMasterBean bean;
		ResultSet resultset = null;
		 bean=null;
		
		try(Connection conn = DBConnection.getInstance().getConnection();) 
		{
			
			PreparedStatement preparedStatement=
				conn.prepareStatement(QueryMapper.VIEW_FACULTY_REPORT);
			
			preparedStatement.setDate(1, startDate);
			preparedStatement.setDate(2, endDate);
			resultset=preparedStatement.executeQuery();
			
			while(resultset.next())
			{
				bean = new FeedbackMasterBean();
				bean.setPresentationCommunication(resultset.getInt(1));
				bean.setClearifyDoubts(resultset.getInt(2));
				bean.setTimeManagement(resultset.getInt(3));
				feedbackList.add(bean);
			}
		}
		catch(Exception e) 
		{
			throw new FeedBackException(e.getMessage());
		}
		
		return feedbackList;
	}

	@Override
	public FacultySkillBean retrieveFaculty(String facultyCode) throws FeedBackException {
		FacultySkillBean bean;
		ResultSet resultset = null;
		 bean=null;
		
		try(Connection conn = DBConnection.getInstance().getConnection();) 
		{
			
			PreparedStatement preparedStatement=
				conn.prepareStatement(QueryMapper.RETRIEVE_FACULTY);
			
			preparedStatement.setString(1,facultyCode);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new FacultySkillBean();
				bean.setSkillSet(resultset.getString(1));
				bean.setFacultyName(resultset.getString(2));
			}
		}
		catch(Exception e) 
		{
			throw new FeedBackException(e.getMessage());
		}
		
		return bean;
	}

	@Override
	public String retrieveFacultyCode(String trainingCode) throws FeedBackException {
		ResultSet resultset = null;
		 String facultyCode=null;
		try(Connection conn = DBConnection.getInstance().getConnection();) 
		{
			
			PreparedStatement preparedStatement=
				conn.prepareStatement(QueryMapper.RETRIEVE_FACULTYCODE);
			
			preparedStatement.setString(1,trainingCode);
			resultset=preparedStatement.executeQuery();
			while(resultset.next()){
				facultyCode=resultset.getString("FacultyCode");
			}
			
		}
		catch(Exception e) 
		{
			throw new FeedBackException(e.getMessage());
		}
		
		return facultyCode;
	}
	}


