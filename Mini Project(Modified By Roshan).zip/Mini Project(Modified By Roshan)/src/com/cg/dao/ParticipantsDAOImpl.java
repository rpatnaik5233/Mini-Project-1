package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;
import com.cg.util.DBConnection;




public class ParticipantsDAOImpl implements IParticipantsDAO {

	@Override
	public boolean participantFeedback(FeedbackMasterBean feedBack)
			throws FeedBackException {
	Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
	
		int record=0;
		boolean isInserted=false;
		
		try {
			
			preparedStatement=connection.prepareStatement(QueryMapper.PARTICIPANT_FEEDBACK);
			preparedStatement.setString(1, feedBack.getTrainingCode());
			preparedStatement.setString(2, feedBack.getParticipantCode());
			preparedStatement.setInt(3, feedBack.getPresentationCommunication());
			preparedStatement.setInt(4, feedBack.getClearifyDoubts());
			preparedStatement.setInt(5, feedBack.getTimeManagement());
			preparedStatement.setInt(6, feedBack.getHandOuts());
			preparedStatement.setInt(7, feedBack.getHwSwNtwrk());
			preparedStatement.setString(8, feedBack.getComments());
			preparedStatement.setString(9, feedBack.getSuggestions());
			
			record=preparedStatement.executeUpdate();
		
			if(record!=0)
			{
				return isInserted;
			}
			else
			{
			
				throw new FeedBackException("Record not inserted");
			}
		
		} 
			catch(SQLException s)
			{
				s.printStackTrace();
			}
		catch (FeedBackException e) {
			e.getMessage();
		}
		
		return isInserted;
	}
	

	@Override
	public String retrieveTrCode(String employeeCode) {
		
		return null;
	}

	
}



